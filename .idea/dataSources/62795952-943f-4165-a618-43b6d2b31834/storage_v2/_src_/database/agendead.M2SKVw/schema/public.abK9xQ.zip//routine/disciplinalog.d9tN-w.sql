create function disciplinalog() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
    INSERT INTO disciplina_log VALUES (old.id, old.cargahoraria, old.nome, old.professorresponsavel_id, old.horario);
    RETURN NEW;
END
$$;

alter function disciplinalog() owner to postgres;

