create function calculaidade(cpf_func character varying) returns integer
    language plpgsql
as
$$
begin
	select extract(year from age(datanasc)) from funcionario where cpf=cpf_func;
end
$$;

alter function calculaidade(varchar) owner to postgres;

