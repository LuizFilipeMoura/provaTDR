create function atualizaidade() returns trigger
    language plpgsql
as
$$
begin
	new.idadefunc = idadefunc(new.cpf);
end
$$;

alter function atualizaidade() owner to postgres;

